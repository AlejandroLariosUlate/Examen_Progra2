/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.MetodosBiblioteca;
import Vista.Frm_VentanaPrincipal;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author Alejandro
 */
public class Controlador_Frm_VentanaPrincipal implements ActionListener {

    MetodosBiblioteca metodos;
    Frm_VentanaPrincipal frm_VentanaPrincipal;
    
    public Controlador_Frm_VentanaPrincipal(Frm_VentanaPrincipal frm_VentanaPrincipal){
        metodos = new MetodosBiblioteca();
        this.frm_VentanaPrincipal = frm_VentanaPrincipal;
    }
    public void actionPerformed(ActionEvent e) {
        if(e.getActionCommand().equals("Buscar")){
            buscar();
        }
        
        if(e.getActionCommand().equals("Agregar")){
            metodos.agregarLibro(frm_VentanaPrincipal.devolverInformacion());
            frm_VentanaPrincipal.mostrarMensaje("Usuario agregado.");
            frm_VentanaPrincipal.limpiar();
            frm_VentanaPrincipal.hablitarBotones();
        }
        if(e.getActionCommand().equals("Modificar")){
            metodos.modificarLibro(frm_VentanaPrincipal.devolverInformacion());
            frm_VentanaPrincipal.mostrarMensaje("Usuario modificado.");
            frm_VentanaPrincipal.limpiar();
            frm_VentanaPrincipal.hablitarBotones();
        }
        if(e.getActionCommand().equals("Eliminar")){
            metodos.eliminarLibro(frm_VentanaPrincipal.devolverNumeroDePrestamo());
            frm_VentanaPrincipal.mostrarMensaje("Usuario eliminado.");
            frm_VentanaPrincipal.limpiar();
            frm_VentanaPrincipal.hablitarBotones();
        }
    }
    public void buscar(){
        if(metodos.buscarLibro(frm_VentanaPrincipal.devolverNumeroDePrestamo())){
            frm_VentanaPrincipal.mostrarInformacion(metodos.devolverArreglo());
            frm_VentanaPrincipal.habilitarDos();
            frm_VentanaPrincipal.desHabilitarCamposModificar();
        }else{
            frm_VentanaPrincipal.mostrarMensaje("Prestamo de libro no encontrado.");
            frm_VentanaPrincipal.habilitarCampos();
            frm_VentanaPrincipal.habilitarAgregar();
            frm_VentanaPrincipal.limpiar();
            
        }
    }
}
