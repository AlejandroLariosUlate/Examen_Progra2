/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.ArrayList;

/**
 *
 * @author Alejandro
 */
public class MetodosBiblioteca {
    ArrayList<Biblioteca>arrayBiblioteca;
    private String[] informacionConsultada = new String[3];
    
    public MetodosBiblioteca(){
        arrayBiblioteca = new ArrayList<Biblioteca>();
    }
    
    public void agregarLibro(String arreglo[]){
        Biblioteca bibliotecaTemp = new Biblioteca(arreglo[0], arreglo[1], arreglo[2], arreglo[3]);
        arrayBiblioteca.add(bibliotecaTemp);
    }//Metodo para agregar libro
    
    public boolean buscarLibro(String numeroDePrestamo){
        boolean existe = false;
        for(int contador=0; contador<arrayBiblioteca.size();contador++){
            if(arrayBiblioteca.get(contador).getNumeroDePrestamo().equals(numeroDePrestamo)){
                informacionConsultada[0]=arrayBiblioteca.get(contador).getNombreDelUsuario();
                informacionConsultada[1]=arrayBiblioteca.get(contador).getCedulaDelUsuario();
                informacionConsultada[2]=arrayBiblioteca.get(contador).getIsbnDelLibro();
                existe = true;
            }
        }
        return existe;
    }//Metodo para buscar libro
    
    public String[] devolverArreglo(){
        return this.informacionConsultada;
    }//Metodo para devolver arreglo
    
    public void modificarLibro(String[] arreglo){
         for(int contador=0; contador<arrayBiblioteca.size();contador++){
            if(arrayBiblioteca.get(contador).getNumeroDePrestamo().equals(arreglo[0])){
                arrayBiblioteca.get(contador).setNombreDelUsuario(informacionConsultada[0]);
                arrayBiblioteca.get(contador).setCedulaDelUsuario(informacionConsultada[1]);
                arrayBiblioteca.get(contador).setIsbnDelLibro(informacionConsultada[2]);
            }
         }
    }//Metodo para modificar el libro
    
    public void eliminarLibro(String numeroDePrestamo){
        for(int contador=0; contador<arrayBiblioteca.size();contador++){
            if(arrayBiblioteca.get(contador).getNumeroDePrestamo().equals(numeroDePrestamo)){
                arrayBiblioteca.remove(contador);
            }
        }
    }//Metodo para eliminar el libro.
}