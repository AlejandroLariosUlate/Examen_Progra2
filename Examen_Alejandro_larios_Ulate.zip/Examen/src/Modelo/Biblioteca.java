/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author Alejandro
 */
public class Biblioteca {
    private String numeroDePrestamo, nombreDelUsuario, cedulaDelUsuario, isbnDelLibro;

    public Biblioteca(String numeroDePrestamo, String nombreDelUsuario, String cedulaDelUsuario, String isbnDelLibro) {
        this.numeroDePrestamo = numeroDePrestamo;
        this.nombreDelUsuario = nombreDelUsuario;
        this.cedulaDelUsuario = cedulaDelUsuario;
        this.isbnDelLibro = isbnDelLibro;
    }

    public String getNumeroDePrestamo() {
        return numeroDePrestamo;
    }

    public void setNumeroDePrestamo(String numeroDePrestamo) {
        this.numeroDePrestamo = numeroDePrestamo;
    }

    public String getNombreDelUsuario() {
        return nombreDelUsuario;
    }

    public void setNombreDelUsuario(String nombreDelUsuario) {
        this.nombreDelUsuario = nombreDelUsuario;
    }

    public String getCedulaDelUsuario() {
        return cedulaDelUsuario;
    }

    public void setCedulaDelUsuario(String cedulaDelUsuario) {
        this.cedulaDelUsuario = cedulaDelUsuario;
    }

    public String getIsbnDelLibro() {
        return isbnDelLibro;
    }

    public void setIsbnDelLibro(String isbnDelLibro) {
        this.isbnDelLibro = isbnDelLibro;
    }
    
    public String getInformacion(){
        return "Número de Préstamo: "+getNumeroDePrestamo()+".\nNombre del Usuario: "+getNombreDelUsuario()+".\nCédula del Usuario: "+getCedulaDelUsuario()+".\nISBN del Libro: "+getIsbnDelLibro()+".";
    }
}
